protocol AbstractOperation {
    func operate(firstNumber: Double, secondNumber: Double) -> Double?
}

//더하기 연산 클래스
class AddOperation: AbstractOperation {
    func operate(firstNumber: Double, secondNumber: Double) -> Double? { firstNumber + secondNumber }
}

//빼기 연산 클래스
class SubtractOperation: AbstractOperation {
    func operate(firstNumber: Double, secondNumber: Double) -> Double? { firstNumber - secondNumber }
}

//곱하기 연산 클래스
class MultiplyOperation: AbstractOperation {
    func operate(firstNumber: Double, secondNumber: Double) -> Double? { firstNumber * secondNumber }
}

// 나누기 연산 클래스 (0으로 나누기 예외처리)
class DivideOperation: AbstractOperation {
    func operate(firstNumber: Double, secondNumber: Double) -> Double? {
        guard secondNumber != 0 else {
            print("0으로 나눌 수 없습니다.")
            return nil
        }
        return firstNumber / secondNumber
    }
}

//나머지 연산 클래스 (0으로 나누기 예외처리 + `truncatingRemainder()` 적용)
class RemainderOperation: AbstractOperation {
    func operate(firstNumber: Double, secondNumber: Double) -> Double? {
        guard secondNumber != 0 else {
            print("0으로 나눌 수 없습니다.")
            return nil
        }
        return firstNumber.truncatingRemainder(dividingBy: secondNumber)
    }
}

//Calculator 클래스
class Calculator {
    func calculate(_ operation: AbstractOperation, _ num1: Double, _ num2: Double) -> String {
        guard let result = operation.operate(firstNumber: num1, secondNumber: num2) else {
            return "undefined"  //nil이면 "undefined" 반환
        }
        return "\(result)"  //정상적인 경우 숫자를 문자열로 변환하여 반환
    }
}


//Calculator 인스턴스 생성
let calculator = Calculator()

//연산 객체 생성
let add = AddOperation()
let sub = SubtractOperation()
let mul = MultiplyOperation()
let div = DivideOperation()
let mod = RemainderOperation()

print("[사칙연산 테스트]")

//덧셈 테스트
print("10 + 5 =", calculator.calculate(add, 10, 5))  // "15.0"
print("99.9 + 0.1 =", calculator.calculate(add, 99.9, 0.1))  // "100.0"

//뺄셈 테스트
print("20 - 8 =", calculator.calculate(sub, 20, 8))  // "12.0"
print("0 - 50 =", calculator.calculate(sub, 0, 50))  // "-50.0"

//곱셈 테스트
print("3 × 7 =", calculator.calculate(mul, 3, 7))  // "21.0"
print("5 × 0 =", calculator.calculate(mul, 5, 0))  // "0.0"

//나눗셈 테스트 (정상)
print("100 ÷ 4 =", calculator.calculate(div, 100, 4))  // "25.0"
print("10 ÷ 3 =", calculator.calculate(div, 10, 3))  // "3.3333333333333335"

//나눗셈 테스트 (0으로 나누기 예외 처리)
print("10 ÷ 0 =", calculator.calculate(div, 10, 0))  // "undefined"

//나머지 연산 테스트
print("10 % 3 =", calculator.calculate(mod, 10, 3))  // "1.0"
print("5 % 2 =", calculator.calculate(mod, 5, 2))  // "1.0"

//나머지 연산 (0으로 나누기 예외 처리)
print("10 % 0 =", calculator.calculate(mod, 10, 0))  // "undefined"
